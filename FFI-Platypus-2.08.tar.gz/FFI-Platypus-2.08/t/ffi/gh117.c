#include "libtest.h"

EXTERN uint64_t
gh117()
{
  return 0xffffffffff;
}
