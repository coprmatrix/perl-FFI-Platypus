int
answer(void)
{
  /* the answer to life the universe and everything */
  return 42;
}
