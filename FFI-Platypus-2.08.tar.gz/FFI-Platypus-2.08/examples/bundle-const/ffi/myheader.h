#ifndef MYHEADER_H
#define MYHEADER_H

#define MYVERSION_STRING "1.2.3"
#define MYVERSION_MAJOR 1
#define MYVERSION_MINOR 2
#define MYVERSION_PATCH 3

enum {
  MYBAD = -1,
  MYOK  = 1
};

#define MYPI 3.14

#endif
