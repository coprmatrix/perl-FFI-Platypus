void
swap(int *a, int *b)
{
  int tmp = *b;
  *b = *a;
  *a = tmp;
}
