#include <libdontpanic.h>

int myanswer()
{
  return answer();
}
