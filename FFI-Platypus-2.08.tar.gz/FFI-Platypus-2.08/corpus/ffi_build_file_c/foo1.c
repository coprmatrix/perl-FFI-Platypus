int
foo1()
{
  return 42;
}
