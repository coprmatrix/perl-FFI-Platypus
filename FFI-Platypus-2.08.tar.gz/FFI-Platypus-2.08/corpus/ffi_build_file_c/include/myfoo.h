#ifndef MYFOO_H
#define MYFOO_H

/* this doesn't do anything apparently */

#endif
