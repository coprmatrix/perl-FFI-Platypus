#include <myfoo.h>
int
foo1()
{
  return 42;
}
