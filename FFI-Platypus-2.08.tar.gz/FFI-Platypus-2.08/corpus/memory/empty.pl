use strict;
use warnings;

print "nada\n";
