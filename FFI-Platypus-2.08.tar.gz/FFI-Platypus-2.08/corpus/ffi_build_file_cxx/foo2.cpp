#include <myfoo.h>

class Foo {
  public:
    int answer() { return 42; };
};

int
foo1()
{
  // comment
  return 42;
}
